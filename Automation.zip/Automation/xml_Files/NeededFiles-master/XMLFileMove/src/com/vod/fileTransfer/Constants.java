package com.vod.fileTransfer;

public class Constants {
	static final String FILES_TO_BE_PROCESSED_LOCATION = "fileToBeProcessedLoaction";
	static final String FILES_TO_BE_COPIED_LOCATION = "fileToBeCopiedLoaction";
	static final String PROPERTY_FILE_LOCATION = "D:/xmlauto/config.properties";
	static final String HEADERS ="headers";
}